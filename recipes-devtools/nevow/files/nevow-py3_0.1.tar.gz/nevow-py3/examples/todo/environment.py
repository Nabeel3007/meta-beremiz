class Env(object):
    user='test'
    password='test'
    port=5432
    host='localhost'
    dbname='todo'
    development=False
env = Env()
