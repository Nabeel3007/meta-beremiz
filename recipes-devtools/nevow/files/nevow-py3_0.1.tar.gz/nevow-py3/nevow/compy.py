# Copyright (c) 2004 Divmod.
# See LICENSE for details.

"""Compatibility wrapper over new twisted.python.components,
so that nevow works with it. 
"""

import warnings

from zope.interface import Interface, implementer as zimplements, Attribute

from twisted.python.components import *

warnings.warn("compy.py module is deprecated, use zope.interface and twisted.python.components.registerAdapter directly.",
              stacklevel=2)

# Backwards compat code
CannotAdapt = TypeError

_registerAdapter = registerAdapter
def registerAdapter(adapterFactory, origInterface, *interfaceClasses):
    from nevow.util import _namedAnyWithBuiltinTranslation, _NamedAnyError
    
    isStr = type(adapterFactory) is str
    if (type(origInterface) is str) != isStr:
        raise ValueError("Either all arguments must be strings or all must be objects.")
    
    for interfaceClass in interfaceClasses:
        if (type(interfaceClass) is str) != isStr:
            raise ValueError("Either all arguments must be strings or all must be objects.")

    if isStr:
        # print "registerAdapter:",adapterFactory, origInterface, interfaceClasses
        adapterFactory = _namedAnyWithBuiltinTranslation(adapterFactory)
        origInterface = _namedAnyWithBuiltinTranslation(origInterface)
        interfaceClasses = [_namedAnyWithBuiltinTranslation(x) for x in interfaceClasses]

    if 'nevow.inevow.ISerializable' in interfaceClasses or [o for o in interfaceClasses if getattr(o, '__name__', None) == 'ISerializable']:
        warnings.warn("ISerializable is deprecated. Please use nevow.flat.registerFlattener instead.", stacklevel=2)
        from nevow import flat
        flat.registerFlattener(adapterFactory, origInterface)
    _registerAdapter(adapterFactory, origInterface, *interfaceClasses)


class IComponentized(Interface):
    pass

_Componentized = Componentized
@zimplements(IComponentized)
class Componentized(_Componentized):
    
    
    def __init__(self, adapterCache=None):
        _Componentized.__init__(self)
        if adapterCache:
            for k, v in list(adapterCache.items()):
                self.setComponent(k, v)


__all__ = ['globalRegistry', 'registerAdapter', 'backwardsCompatImplements', 'fixClassImplements',
           'getInterfaces', 'IComponentized', 'Componentized', 'Adapter', 'CannotAdapt']
