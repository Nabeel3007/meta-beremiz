
/**
 * Extra module which one of the tests will need to load dynamically in order
 * to succeed.
 */

// import Nevow.Athena

Nevow.Athena.Tests.Resources.ImportWidget = Nevow.Athena.Widget.subclass("Nevow.Athena.Tests.Resources.ImportWidget");
